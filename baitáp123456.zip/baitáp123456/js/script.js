/* ==========================================================================
   JAVASCRIPT CHO BÀI 5: MODERN HAMBURGER MENU
   Chỉ sử dụng một lượng nhỏ JS cơ bản để bật/tắt (toggle) class .active
   ========================================================================== */

// 1. Lấy các phần tử DOM cần thao tác
const hamburger = document.querySelector('.hamburger');
const navMenu = document.querySelector('.nav-menu');
const navLinks = document.querySelectorAll('.nav-link');

// 2. Lắng nghe sự kiện click vào biểu tượng Hamburger
hamburger.addEventListener('click', () => {
  // Thêm hoặc xóa class 'active' trên nút hamburger để kích hoạt hiệu ứng xoay thành dấu 'X'
  hamburger.classList.toggle('active');
  
  // Thêm hoặc xóa class 'active' trên navMenu để mở hoặc đóng menu trên mobile
  navMenu.classList.toggle('active');
});

// 3. Tự động đóng menu khi người dùng nhấn vào bất kỳ liên kết nào trong menu
navLinks.forEach(link => {
  link.addEventListener('click', () => {
    hamburger.classList.remove('active');
    navMenu.classList.remove('active');
  });
});
